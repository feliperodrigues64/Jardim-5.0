#ifndef I2C_BUS_DEVICEID_H_
#define I2C_BUS_DEVICEID_H_
NAN_METHOD(DeviceIdAsync);
NAN_METHOD(DeviceIdSync);
#endif // I2C_BUS_DEVICEID_H_

