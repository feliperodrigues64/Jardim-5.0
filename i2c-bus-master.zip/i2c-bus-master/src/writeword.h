#ifndef I2C_BUS_WRITEWORD_H_
#define I2C_BUS_WRITEWORD_H_
NAN_METHOD(WriteWordAsync);
NAN_METHOD(WriteWordSync);
#endif // I2C_BUS_WRITEWORD_H_

