#ifndef I2C_BUS_SETADDR_H_
#define I2C_BUS_SETADDR_H_
NAN_METHOD(SetAddrAsync);
NAN_METHOD(SetAddrSync);
#endif // I2C_BUS_SETADDR_H_

