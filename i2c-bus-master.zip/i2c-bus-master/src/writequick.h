#ifndef I2C_BUS_WRITEQUICK_H_
#define I2C_BUS_WRITEQUICK_H_
NAN_METHOD(WriteQuickAsync);
NAN_METHOD(WriteQuickSync);
#endif // I2C_BUS_WRITEQUICK_H_

